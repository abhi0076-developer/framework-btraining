from django.shortcuts import render, redirect
from .forms import HackathonRegistrationForm

def register_team(request):
    if request.method=='POST':
        form=HackathonRegistrationForm(request.POST)
        if form.is_valid():
            form.save()  #inserting data
            return redirect('success')
    
    else:
        form=HackathonRegistrationForm()
    return render(request,'hackathon_form.html',{'form':form})

def success(request):
    return render(request,"success.html")
