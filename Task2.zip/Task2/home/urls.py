from django.urls import path
from.import views

urlpatterns=[
   path('', views.register_team, name='home'),
    path('hackathon/register/', views.register_team, name='register_team'),
    path('success/', views.success, name='success'),
]

