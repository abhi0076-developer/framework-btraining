
from django.db import models

class HackathonRegistration(models.Model):
    team_name=models.CharField(max_length=100)
    team_lead_name=models.CharField(max_length=100)
    lead_email=models.EmailField(unique=True)
    lead_phone=models.CharField(max_length=15)
    college=models.CharField(max_length=100)
    
    def _str_(self):
        return self.name
    
