from django import forms
from .models import HackathonRegistration

class HackathonRegistrationForm(forms.ModelForm):
    class Meta:
        model=HackathonRegistration
        fields=['team_name','team_lead_name','lead_email','lead_phone','college']