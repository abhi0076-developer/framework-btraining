from django.apps import AppConfig


class AnjaliConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'anjali'
