from django.shortcuts import render
from django.http import HttpResponse
def home(request):
    return HttpResponse("My self jaya anjali.i am recently graduated in sri venkateswara college of engineering inthe stream of computer science and engineering.I have a technical knowledge in python full stack")
