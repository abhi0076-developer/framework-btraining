from django.shortcuts import render
from django.http import HttpResponse
def home(request):
    return HttpResponse("my self jaya anjali.I graduated BTECH in sri venkateswara college of engineering in the stream of CSE(AI&ML).I have a technical knowledge in python full stack.I want to gain my knowlede and expand my skills in doing the projects through this company .")
